/* public class Prueba {
    public static void main(String[] args) {
        
        Serie umbrella = new Serie(4);
        Temporada temporadaDos = new Temporada(3);
        int capTotales = temporadaDos.getCantidadCapitulos();

        System.out.println("La temporada 2 tiene: " + capTotales + " capitulos");

        temporadaDos.actualizarCalificacion(0, 5);
        temporadaDos.actualizarCalificacion(1, 4);

        int capVistos = temporadaDos.capitulosVistos();

        System.out.println("Se vieron: " + capVistos + " capitulos");

        double promedio = temporadaDos.promedioCalifiTempo();
        System.out.println("El promedio de valoracion de la temporada es " + promedio);

    }
} */
