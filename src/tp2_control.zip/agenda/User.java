/* package agenda;

public class User {

    private String name;
    private int celular;
    private String email;

    public User(String name, int celular, String email){
        this.name = name;
        this.celular = celular;
        this.email = email;
    }

    public void setCelular(int celular){
        this.celular = celular;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public int getCelular(){
        return this.celular;
    }

    public String getEmail(){
        return this.email;
    }

    @Override
    public String toString() {
        return "User{name='" + name + "'}";
    }
}
*/