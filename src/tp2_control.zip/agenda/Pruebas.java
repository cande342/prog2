/* package agenda;
import java.time.LocalDateTime;

public class Pruebas {
    public static void main(String[] args) {
        
        User usuario1 = new User("Samira", 24356700, "samira@lol.com");
        User usuraio2 = new User("Nasus", 273680, "nasus@lol.com");
        User usuario3 = new User("Ahri", 2734567, "ahri@lol.com");
        User usuraio4 = new User("Ezreal", 1112567, "YarroPlumaluz@lol.com");
        User[] usuarios = { usuario1, usuraio2};
        User[] usuarios2 = { usuario3, usuraio4};

        Reunion reu1 = new Reunion("Grieta del Invocador",
                                    usuarios, "Tirar top", LocalDateTime.of(2024, 8, 15, 12, 0),
                                    LocalDateTime.of(2024, 8, 15, 12, 30));

        Reunion reu2 = new Reunion("Abismo de los lamentos",
                                    usuarios2, "Ganar", LocalDateTime.of(2024, 8, 15, 11, 0),
                                    LocalDateTime.of(2024, 8, 15, 12, 30));

        Agendar miAgenda = new Agendar();

        miAgenda.agregarReunion(reu2);
        miAgenda.agregarReunion(reu1);
    }
}
*/