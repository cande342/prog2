package tp2_control;

/* public class Pruebas {

    public static void main(String[] args) {
                // Crear algunas ciudades con diferentes gastos y poblaciones
                Ciudad ciudad1 = new Ciudad("Narnia", 200000, 120000); // En déficit
                Ciudad ciudad2 = new Ciudad("Panem", 150000, 90000);  // No en déficit
                Ciudad ciudad3 = new Ciudad("Esparta", 300000, 110000); // En déficit
                Ciudad ciudad4 = new Ciudad( "Noxus",100000, 105000); // No en déficit
                Ciudad ciudad5 = new Ciudad("Demacia",250000, 115000); // En déficit
        
                // Crear provincias y agregar ciudades a ellas
                Provincia provincia1 = new Provincia("Provincia A", 4);
                provincia1.agregarCiudad(ciudad1);
                provincia1.agregarCiudad(ciudad2);
        
                Provincia provincia2 = new Provincia("Provincia B", 6);
                provincia2.agregarCiudad(ciudad3);
                provincia2.agregarCiudad(ciudad4);
        
                Provincia provincia3 = new Provincia("Provincia C", 1);
                provincia3.agregarCiudad(ciudad5);
        
                // Crear un país y agregar provincias a él
                Pais pais = new Pais();
                pais.agregarProvincia(provincia1);
                pais.agregarProvincia(provincia2);
                pais.agregarProvincia(provincia3);
        
                // Imprimir ciudades en déficit en el país
                pais.imprimirCiudadesEnDeficit();
    }
}
*/