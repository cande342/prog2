/* package tp2_control;

public class Impuestos {

    private String nombre;
    private double monto;

    public Impuestos(String nombre, double monto){
        this.nombre = nombre;
        this.monto = monto;
    }

    public void setNombre( String nombre){
        this.nombre = nombre;
    }

    public void setMonto( double monto){
        this.monto = monto;
    }

    public String getNombre(){
        return this.nombre;
    }

    public double getMonto(){
        return this.monto;
    }
}

*/